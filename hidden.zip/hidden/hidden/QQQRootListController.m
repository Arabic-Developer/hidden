//تمت كتابة الاكواد بواسطة عبدالحميد.
//تم انشاء الاداة من قبل احمد.
//اذا قمت بتطوير الاداة في المستقبل لا تنسي. الحقوق



#include "QQQRootListController.h"
#import <CepheiPrefs/HBAppearanceSettings.h>

@implementation QQQRootListController

- (NSArray *)specifiers {
	if (!_specifiers) {
		_specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
	}

	return _specifiers;
}

-(void)respring {
	[HBRespringController respring];
}
@end